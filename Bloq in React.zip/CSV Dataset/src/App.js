// Dashboard.js
import React, { useState } from 'react';
import './index.css';

const Dashboard = () => {
  const [theme, setTheme] = useState('light');
  const [problemType, setProblemType] = useState('Machine Learning');
  const [numQubits, setNumQubits] = useState(2);
  const [selectedDataset, setSelectedDataset] = useState('Credit Card Fraud');
  const [circuitDepth, setCircuitDepth] = useState(1);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('QSVC');
  const [selectedDevice, setSelectedDevice] = useState('Statevector Simulator');
  const [selectedFeatureMap, setSelectedFeatureMap] = useState('Z Feature Map');
  const [csvFile, setCsvFile] = useState(null);

  // Dropdown options
  const problemTypeOptions = ['Machine Learning', 'Optimization'];
  const datasetOptions = ['Credit Card Fraud', 'Electricity Theft', 'Breast Cancer'];
  const algorithmOptions = ['QSVC', 'AQSVC', 'QKT', 'QNN'];
  const circuitDepthOptions = [1, 2, 3, 4];
  const deviceOptions = ['Statevector Simulator', 'QASM Simulator'];
  const featureMapOptions = ['Pauli Feature', 'Z Feature', 'ZZ Feature', 'Efficient SU2'];
  const numQubitsOptions = [2, 3, 4, 5, 6, 7, 8];

  // Function to handle dropdown changes
  const handleDropdownChange = (setStateFunction) => (e) => {
    setStateFunction(e.target.value);
  };

  // Function to handle 'Run' button click
  const handleRunButtonClick = () => {
    // Add logic to run the quantum algorithm
    console.log('Running quantum algorithm...');
  };

  // Function to handle 'Display' button click
  const handleDisplayButtonClick = () => {
    // Add logic to display results
    console.log('Displaying results...');
  };

  // Function to handle file upload
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setCsvFile(file);
      console.log('File uploaded:', file.name);
      // Add logic to handle the uploaded file, such as sending it to the backend
    }
  };

  // Function to toggle theme
  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  return (
    <div className={`dashboard ${theme}`}>
      <header>
        <h1>Quantum Bloq - Main Dashboard</h1>
        <button className="theme-toggle" onClick={toggleTheme}>
        </button>
      </header>
      <main>
        {/* ... Existing sections ... */}

        <section>
          <h2>Problem Type:</h2>
          <div className="dropdown-container">
            <select value={problemType} onChange={handleDropdownChange(setProblemType)}>
              {problemTypeOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </section>
        <section>
          <h2>Dataset:</h2>
          <div className="dropdown-container">
            <select value={selectedDataset} onChange={handleDropdownChange(setSelectedDataset)}>
              {datasetOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </section>
        <section>
          <h2>No. of Qubits:</h2>
          <div className="dropdown-container">
            <select value={numQubits} onChange={handleDropdownChange(setNumQubits)}>
              {numQubitsOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </section>
        <section>
          <h2>Circuit Depth:</h2>
          <div className="dropdown-container">
            <select value={circuitDepth} onChange={handleDropdownChange(setCircuitDepth)}>
              {circuitDepthOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </section>
        <section>
          <h2>Algorithm:</h2>
          <div className="dropdown-container">
            <select value={selectedAlgorithm} onChange={handleDropdownChange(setSelectedAlgorithm)}>
              {algorithmOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </section>
        <section>
          <h2>Device:</h2>
          <div className="dropdown-container">
            <select value={selectedDevice} onChange={handleDropdownChange(setSelectedDevice)}>
              {deviceOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </section>
        <section>
          <h2>Feature Map:</h2>
          <div className="dropdown-container">
            <select value={selectedFeatureMap} onChange={handleDropdownChange(setSelectedFeatureMap)}>
              {featureMapOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </section>
        <section>
          <h2>Upload CSV:</h2>
          <div className="file-upload-container">
            <input type="file" accept=".csv" onChange={handleFileUpload} />
          </div>
        </section>
        <section>
         
          <div className="button-container">
            <button className="vertical-button" onClick={handleRunButtonClick}>
              Run
            </button>
          </div>
        </section>
        <section>
          <div className="button-container">
            <button className="vertical-button" onClick={handleDisplayButtonClick}>
              Display
            </button>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Dashboard;
